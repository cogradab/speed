#!/usr/bin/env python
import sys

from grove_rgb_lcd import *

# Slowly change the colors every 0.01 seconds.
#for c in range(0,255):
 #   setRGB(c,255-c,0)
  #  time.sleep(0.01)

setRGB(0,0,0)
setText(" ")
